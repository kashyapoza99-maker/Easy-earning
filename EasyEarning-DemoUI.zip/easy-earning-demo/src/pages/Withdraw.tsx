import React, { useState } from 'react'
import { Wallet, TimerReset } from 'lucide-react'

export default function Withdraw(){
  const [amt, setAmt]=useState('')
  const [addr, setAddr]=useState('')
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Withdraw USDT (TRC20)</h2>
      <div className="card card-pad" style={{maxWidth:720}}>
        <div className="badge"><TimerReset size={14}/> 1 request / 24 hours</div>
        <p className="small" style={{marginTop:10}}>Withdraw fee: <b>1 USDT</b>. KYC required for approval.</p>

        <div style={{marginTop:12}}>
          <div className="label">Amount</div>
          <input className="input" value={amt} onChange={e=>setAmt(e.target.value)} placeholder="Enter amount"/>
        </div>
        <div style={{marginTop:12}}>
          <div className="label">Your TRC20 Wallet Address</div>
          <input className="input" value={addr} onChange={e=>setAddr(e.target.value)} placeholder="T...."/>
        </div>

        <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:14}}>
          <Wallet size={18}/> Submit Withdraw Request
        </button>

        <hr/>
        <h3 style={{marginTop:0}}>Withdraw History</h3>
        <table className="table">
          <thead><tr><th>Date</th><th>Amount</th><th>Fee</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>2026-01-21</td><td>20 USDT</td><td>1</td><td>Paid</td></tr>
            <tr><td>2026-01-18</td><td>15 USDT</td><td>1</td><td>Approved</td></tr>
            <tr><td>2026-01-16</td><td>10 USDT</td><td>1</td><td>Rejected</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
