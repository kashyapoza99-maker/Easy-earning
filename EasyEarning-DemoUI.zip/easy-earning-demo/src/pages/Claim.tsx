import React from 'react'
export default function Claim(){
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Daily Claim</h2>
      <div className="card card-pad" style={{maxWidth:720}}>
        <div className="badge">Manual Claim • Every 24 hours</div>
        <h3 style={{margin:'12px 0 6px'}}>Claim Bonus</h3>
        <p className="small">This is a demo page. In a real system, claim timers & bonus rules are controlled by admin settings.</p>
        <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:12}}>
          CLAIM NOW
        </button>
        <p className="small" style={{marginTop:12}}>Next claim available in: 23:59:59</p>
      </div>
    </div>
  )
}
