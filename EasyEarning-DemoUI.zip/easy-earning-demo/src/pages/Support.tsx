import React, { useEffect, useMemo, useState } from 'react'
import { SendHorizonal, Bot } from 'lucide-react'

type Msg = {from:'user'|'bot', text:string}
const FAQ: Record<string,string> = {
  deposit: "To deposit: scan TRC20 QR, pay USDT, upload screenshot. Admin verifies and approves.",
  withdraw: "Withdrawals: fee 1 USDT. Only 1 request per 24 hours. KYC required for approval.",
  kyc: "KYC helps secure withdrawals and prevent fraud. Upload ID + selfie in KYC page.",
  referral: "Referral bonus: 5% (demo). Bonus credited after admin approves referred deposit."
}

export default function Support(){
  const [text,setText]=useState('')
  const [msgs,setMsgs]=useState<Msg[]>([
    {from:'bot', text:"Hello 👋 Welcome to Easy Earning Support. Type: Deposit / Withdraw / KYC / Referral."}
  ])

  const reply = (q:string)=>{
    const key = q.toLowerCase()
    const found = Object.keys(FAQ).find(k=>key.includes(k))
    return found ? FAQ[found] : "Thanks! Our team will reply shortly. (Auto-reply demo)"
  }

  const send=()=>{
    if(!text.trim()) return
    const t=text.trim()
    setMsgs(m=>[...m,{from:'user', text:t},{from:'bot', text: reply(t)}])
    setText('')
  }

  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Support Chat</h2>
      <div className="card card-pad" style={{maxWidth:820}}>
        <div style={{display:'flex', gap:10, alignItems:'center'}}>
          <span className="badge"><Bot size={14}/> AI Auto Reply (Demo)</span>
          <span className="small">24/7 Quick help</span>
        </div>

        <div style={{marginTop:12, height:380, overflow:'auto', padding:12, borderRadius:18, border:'1px solid rgba(255,255,255,.08)', background:'rgba(0,0,0,.25)'}}>
          {msgs.map((m,i)=>(
            <div key={i} style={{display:'flex', justifyContent:m.from==='user'?'flex-end':'flex-start', margin:'10px 0'}}>
              <div style={{
                maxWidth:'75%',
                padding:'10px 12px',
                borderRadius:18,
                border:'1px solid rgba(255,255,255,.08)',
                background: m.from==='user' ? 'linear-gradient(135deg, rgba(212,175,55,.22), rgba(212,175,55,.10))' : 'rgba(255,255,255,.05)'
              }}>
                <div className="small" style={{color:'var(--text)'}}>{m.text}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{display:'flex', gap:10, marginTop:12}}>
          <input className="input" value={text} onChange={e=>setText(e.target.value)} placeholder="Type your message..." onKeyDown={e=>e.key==='Enter'&&send()}/>
          <button className="btn primary" onClick={send}><SendHorizonal size={18}/> Send</button>
        </div>
      </div>
    </div>
  )
}
