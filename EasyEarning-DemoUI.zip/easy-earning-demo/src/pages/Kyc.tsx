import React, { useState } from 'react'
import { UploadCloud, ShieldCheck } from 'lucide-react'

export default function Kyc(){
  const [status] = useState<'Pending'|'Approved'|'Rejected'>('Approved')
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>KYC Verification</h2>
      <div className="card card-pad" style={{maxWidth:760}}>
        <div className="badge"><ShieldCheck size={14}/> Status: {status}</div>
        <p className="small" style={{marginTop:10}}>KYC is mandatory for secure withdrawals and fraud prevention.</p>

        <div className="grid cols-2" style={{marginTop:12}}>
          <div>
            <div className="label">Full Name</div>
            <input className="input" placeholder="Your name"/>
          </div>
          <div>
            <div className="label">ID Number</div>
            <input className="input" placeholder="Aadhaar / PAN"/>
          </div>
        </div>

        <div className="grid cols-2" style={{marginTop:12}}>
          <div className="card" style={{padding:12}}>
            <div className="small">Upload ID Proof</div>
            <label className="btn" style={{marginTop:10}}>
              <input type="file" style={{display:'none'}} />
              <UploadCloud size={18}/> Choose File
            </label>
          </div>
          <div className="card" style={{padding:12}}>
            <div className="small">Upload Selfie</div>
            <label className="btn" style={{marginTop:10}}>
              <input type="file" style={{display:'none'}} />
              <UploadCloud size={18}/> Choose File
            </label>
          </div>
        </div>

        <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:14}}>
          Submit KYC
        </button>
      </div>
    </div>
  )
}
