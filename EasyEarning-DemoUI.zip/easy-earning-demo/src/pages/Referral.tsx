import React from 'react'
import { Copy, BadgePercent } from 'lucide-react'

export default function Referral(){
  const code="EASY-7Q9K"
  const link="https://easy-earning-demo.example/?ref="+code
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Referral & Bonus</h2>
      <div className="grid cols-2">
        <div className="card card-pad">
          <div className="badge"><BadgePercent size={14}/> 5% Bonus (demo)</div>
          <h3 style={{margin:'10px 0 6px'}}>Your Referral Link</h3>
          <div className="card" style={{padding:12}}>
            <div className="small">Code</div>
            <div style={{display:'flex',gap:10,alignItems:'center',justifyContent:'space-between'}}>
              <b>{code}</b>
              <button className="btn" onClick={()=>navigator.clipboard.writeText(code)}><Copy size={16}/> Copy</button>
            </div>
            <div style={{height:10}}/>
            <div className="small">Link</div>
            <div style={{display:'flex',gap:10,alignItems:'center',justifyContent:'space-between'}}>
              <div className="small" style={{wordBreak:'break-all'}}>{link}</div>
              <button className="btn" onClick={()=>navigator.clipboard.writeText(link)}><Copy size={16}/> Copy</button>
            </div>
          </div>
          <p className="small" style={{marginTop:12}}>
            Bonus is credited after admin approves the referred user’s deposit.
          </p>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}>Referral History</h3>
          <table className="table">
            <thead><tr><th>User</th><th>Deposit</th><th>Bonus</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td>user_102</td><td>100 USDT</td><td>5 USDT</td><td>Credited</td></tr>
              <tr><td>user_341</td><td>50 USDT</td><td>2.5 USDT</td><td>Pending</td></tr>
              <tr><td>user_822</td><td>20 USDT</td><td>1 USDT</td><td>Rejected</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
