import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Phone, ShieldCheck, Chrome } from 'lucide-react'

export default function Login(){
  const nav = useNavigate()
  const [mobile, setMobile] = useState('')
  return (
    <div className="container">
      <div className="card card-pad" style={{maxWidth:520, margin:'0 auto'}}>
        <div className="badge"><ShieldCheck size={14}/> Secure Login</div>
        <h2 style={{margin:'12px 0 6px'}}>Login to Easy Earning</h2>
        <p className="small">Continue with Mobile OTP or Google. (Demo screen)</p>

        <div style={{marginTop:14}}>
          <div className="label">Mobile Number</div>
          <input className="input" placeholder="+91 9XXXXXXXXX" value={mobile} onChange={e=>setMobile(e.target.value)}/>
          <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:12}}
            onClick={()=>nav('/dashboard')}>
            <Phone size={18}/> Continue with OTP
          </button>

          <div style={{display:'flex', alignItems:'center', gap:10, margin:'14px 0'}}>
            <div style={{flex:1, height:1, background:'rgba(255,255,255,.08)'}}/>
            <div className="small">or</div>
            <div style={{flex:1, height:1, background:'rgba(255,255,255,.08)'}}/>
          </div>

          <button className="btn" style={{width:'100%', justifyContent:'center'}}
            onClick={()=>nav('/dashboard')}>
            <Chrome size={18}/> Continue with Google
          </button>

          <p className="small" style={{marginTop:14}}>
            By continuing you agree to Terms & Privacy Policy.
            <br/>Admin? <Link to="/admin" style={{color:'var(--gold2)'}}>Open Admin Panel</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
