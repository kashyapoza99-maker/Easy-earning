import React, { useState } from 'react'
import { QrCode, UploadCloud, ShieldAlert } from 'lucide-react'

export default function Recharge(){
  const [amount, setAmount] = useState('')
  const [fileName, setFileName] = useState('No file selected')
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Deposit USDT (TRC20)</h2>
      <div className="grid cols-2" style={{alignItems:'start'}}>
        <div className="card card-pad">
          <div className="badge"><QrCode size={14}/> QR Deposit Only</div>
          <h3 style={{margin:'12px 0 6px'}}>Scan QR to Deposit</h3>
          <p className="small">Wallet address is hidden. Please scan the QR to deposit USDT on TRC20 network.</p>
          <div className="card" style={{padding:16, textAlign:'center'}}>
            <div style={{width:'100%', aspectRatio:'1/1', borderRadius:18, border:'1px dashed rgba(255,255,255,.14)', display:'grid', placeItems:'center'}}>
              <div>
                <QrCode size={64} />
                <div className="small" style={{marginTop:8}}>Place your QR image here</div>
              </div>
            </div>
          </div>
          <p className="small" style={{marginTop:12}}>
            <ShieldAlert size={14} style={{verticalAlign:'-2px'}}/> Only TRC20 supported. Wrong network deposit may be lost.
          </p>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}>Upload Payment Proof</h3>
          <div className="label">Amount (Min 10 USDT)</div>
          <input className="input" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="10"/>
          <div style={{marginTop:12}}>
            <div className="label">Screenshot (Required)</div>
            <div className="card" style={{padding:12}}>
              <div className="small">{fileName}</div>
              <label className="btn" style={{marginTop:10}}>
                <input type="file" style={{display:'none'}} onChange={(e)=>setFileName(e.target.files?.[0]?.name || 'No file selected')}/>
                <UploadCloud size={18}/> Choose File
              </label>
            </div>
          </div>
          <div className="label" style={{marginTop:12}}>Transaction Hash (Optional)</div>
          <input className="input" placeholder="Tx hash (optional)"/>
          <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:14}}>
            Submit Deposit Request
          </button>
          <p className="small" style={{marginTop:12}}>
            Status: Pending → Approved/Rejected after admin verification.
          </p>
        </div>
      </div>
    </div>
  )
}
