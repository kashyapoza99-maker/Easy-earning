import React from 'react'
import { Link } from 'react-router-dom'
import { QrCode, Wallet, BadgePercent, ShieldCheck, MessageCircleMore } from 'lucide-react'

export default function Dashboard(){
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Dashboard</h2>
      <div className="grid cols-4">
        <div className="card card-pad kpi"><span className="small">Available Balance</span><b>128.50 USDT</b></div>
        <div className="card card-pad kpi"><span className="small">Active Deposit</span><b>300.00 USDT</b></div>
        <div className="card card-pad kpi"><span className="small">Today Bonus</span><b>—</b></div>
        <div className="card card-pad kpi"><span className="small">Total Withdrawn</span><b>91.00 USDT</b></div>
      </div>

      <div className="grid cols-2" style={{marginTop:16}}>
        <div className="card card-pad">
          <h3 style={{marginTop:0}}>Quick Actions</h3>
          <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
            <Link className="btn primary" to="/recharge"><QrCode size={18}/> Recharge</Link>
            <Link className="btn" to="/withdraw"><Wallet size={18}/> Withdraw</Link>
            <Link className="btn" to="/referral"><BadgePercent size={18}/> Referral</Link>
            <Link className="btn" to="/kyc"><ShieldCheck size={18}/> KYC</Link>
            <Link className="btn" to="/support"><MessageCircleMore size={18}/> Support</Link>
          </div>
          <p className="small" style={{marginTop:12}}>
            Rules: Min deposit 10 USDT (TRC20). Withdraw fee 1 USDT. 1 withdraw request / 24 hours.
          </p>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}>Recent Activity</h3>
          <table className="table">
            <thead>
              <tr><th>Type</th><th>Amount</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr><td>Deposit</td><td>50 USDT</td><td>Approved</td></tr>
              <tr><td>Withdraw</td><td>20 USDT</td><td>Paid</td></tr>
              <tr><td>KYC</td><td>—</td><td>Approved</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
