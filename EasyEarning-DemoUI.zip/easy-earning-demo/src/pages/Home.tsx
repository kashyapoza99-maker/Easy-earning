import React from 'react'
import { Link } from 'react-router-dom'
import { QrCode, ShieldCheck, BadgePercent, TimerReset, Coins, MessageCircleMore } from 'lucide-react'

export default function Home(){
  return (
    <div className="container">
      <div className="card card-pad" style={{padding:22}}>
        <div className="badge">TRC20 • QR Deposit • Manual Verification</div>
        <h1 style={{margin:'14px 0 8px', fontSize:34}}>Easy Earning</h1>
        <p style={{color:'var(--muted)', marginTop:0, fontSize:16}}>
          A premium black & gold demo UI for a USDT (TRC20) wallet + admin workflow platform.
          Deposits are submitted with screenshot proof and verified manually by admin.
        </p>

        <div style={{display:'flex',gap:12,flexWrap:'wrap',marginTop:16}}>
          <Link className="btn primary" to="/dashboard">Open Dashboard</Link>
          <Link className="btn" to="/recharge"><QrCode size={18}/> Recharge (QR Only)</Link>
          <Link className="btn" to="/support"><MessageCircleMore size={18}/> Support Chat</Link>
        </div>
      </div>

      <div className="grid cols-3" style={{marginTop:16}}>
        <div className="card card-pad">
          <div className="badge"><QrCode size={14}/> QR Deposit</div>
          <h3 style={{margin:'10px 0 6px'}}>TRC20 QR Only</h3>
          <p className="small">Wallet address is hidden. Users deposit via QR and upload screenshot.</p>
        </div>
        <div className="card card-pad">
          <div className="badge"><ShieldCheck size={14}/> Security</div>
          <h3 style={{margin:'10px 0 6px'}}>KYC Protected</h3>
          <p className="small">KYC helps secure withdrawals and prevents fraud activities.</p>
        </div>
        <div className="card card-pad">
          <div className="badge"><TimerReset size={14}/> Rules</div>
          <h3 style={{margin:'10px 0 6px'}}>24H Withdraw Limit</h3>
          <p className="small">Only 1 withdrawal request allowed every 24 hours for system safety.</p>
        </div>
      </div>

      <div className="card card-pad" style={{marginTop:16}}>
        <h2 style={{marginTop:0}}>How it Works</h2>
        <ol style={{color:'var(--muted)', lineHeight:1.8, paddingLeft:18}}>
          <li>Login with Mobile OTP / Google (demo screen)</li>
          <li>Scan QR to deposit USDT (TRC20)</li>
          <li>Upload screenshot proof</li>
          <li>Admin verifies & approves deposit</li>
          <li>Withdraw request goes for admin approval (fee + 24h rule)</li>
        </ol>
        <div className="grid cols-4" style={{marginTop:14}}>
          <div className="kpi"><span className="small">Total Users</span><b>12,408</b></div>
          <div className="kpi"><span className="small">Deposits Verified</span><b>8,112</b></div>
          <div className="kpi"><span className="small">Withdrawals Paid</span><b>6,909</b></div>
          <div className="kpi"><span className="small">Support Response</span><b>24/7</b></div>
        </div>
        <p className="small" style={{marginTop:12}}>
          Note: This package is a <b>demo UI template</b> meant for legitimate platforms and testing. It does not process real crypto payments.
        </p>
      </div>
    </div>
  )
}
