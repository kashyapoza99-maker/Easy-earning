import React from 'react'
import { CheckCircle2, XCircle, Users, FileCheck2, Wallet, QrCode } from 'lucide-react'

export default function AdminDashboard(){
  return (
    <div className="container">
      <h2 style={{marginTop:6}}>Admin Dashboard</h2>

      <div className="grid cols-4">
        <div className="card card-pad kpi"><span className="small">Total Users</span><b>12,408</b></div>
        <div className="card card-pad kpi"><span className="small">Pending Deposits</span><b>18</b></div>
        <div className="card card-pad kpi"><span className="small">Pending Withdraw</span><b>7</b></div>
        <div className="card card-pad kpi"><span className="small">Pending KYC</span><b>3</b></div>
      </div>

      <div className="grid cols-2" style={{marginTop:16}}>
        <div className="card card-pad">
          <h3 style={{marginTop:0}}><Users size={18} style={{verticalAlign:'-3px'}}/> Users</h3>
          <table className="table">
            <thead><tr><th>User</th><th>Status</th><th>KYC</th></tr></thead>
            <tbody>
              <tr><td>user_102</td><td>Active</td><td>Approved</td></tr>
              <tr><td>user_341</td><td>Active</td><td>Pending</td></tr>
              <tr><td>user_822</td><td>Blocked</td><td>Rejected</td></tr>
            </tbody>
          </table>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}><QrCode size={18} style={{verticalAlign:'-3px'}}/> Deposit Requests</h3>
          <table className="table">
            <thead><tr><th>User</th><th>Amount</th><th>Action</th></tr></thead>
            <tbody>
              <tr>
                <td>user_341</td><td>50 USDT</td>
                <td>
                  <button className="btn primary" style={{padding:'8px 10px', marginRight:8}}><CheckCircle2 size={16}/> Approve</button>
                  <button className="btn" style={{padding:'8px 10px'}}><XCircle size={16}/> Reject</button>
                </td>
              </tr>
              <tr>
                <td>user_990</td><td>10 USDT</td>
                <td>
                  <button className="btn primary" style={{padding:'8px 10px', marginRight:8}}><CheckCircle2 size={16}/> Approve</button>
                  <button className="btn" style={{padding:'8px 10px'}}><XCircle size={16}/> Reject</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}><Wallet size={18} style={{verticalAlign:'-3px'}}/> Withdraw Requests</h3>
          <table className="table">
            <thead><tr><th>User</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td>user_102</td><td>20 USDT</td><td>Paid</td></tr>
              <tr><td>user_341</td><td>15 USDT</td><td>Pending</td></tr>
              <tr><td>user_990</td><td>10 USDT</td><td>Approved</td></tr>
            </tbody>
          </table>
        </div>

        <div className="card card-pad">
          <h3 style={{marginTop:0}}><FileCheck2 size={18} style={{verticalAlign:'-3px'}}/> KYC</h3>
          <p className="small">Review documents and approve/reject.</p>
          <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
            <button className="btn primary" style={{padding:'10px 12px'}}><CheckCircle2 size={18}/> Approve</button>
            <button className="btn" style={{padding:'10px 12px'}}><XCircle size={18}/> Reject</button>
          </div>
        </div>
      </div>

      <p className="small" style={{marginTop:14}}>
        Note: Admin dashboard is a UI demo. No real crypto processing is included.
      </p>
    </div>
  )
}
