import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { LockKeyhole } from 'lucide-react'

const ADMIN_EMAIL = "admin@easyearning"
const ADMIN_PASS  = "easy6353@"

export default function AdminLogin(){
  const nav = useNavigate()
  const [email,setEmail]=useState('')
  const [pass,setPass]=useState('')
  const [err,setErr]=useState('')
  const submit=()=>{
    if(email.trim()===ADMIN_EMAIL && pass===ADMIN_PASS){
      nav('/admin/dashboard')
    }else{
      setErr('Invalid admin credentials (demo).')
    }
  }
  return (
    <div className="container">
      <div className="card card-pad" style={{maxWidth:520, margin:'0 auto'}}>
        <div className="badge"><LockKeyhole size={14}/> Admin Panel</div>
        <h2 style={{margin:'12px 0 6px'}}>Admin Login</h2>
        <p className="small">Demo credentials are pre-set.</p>
        <div style={{marginTop:12}}>
          <div className="label">Email</div>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder={ADMIN_EMAIL}/>
        </div>
        <div style={{marginTop:12}}>
          <div className="label">Password</div>
          <input className="input" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••"/>
        </div>
        {err && <div className="small" style={{color:'#ffb4b4', marginTop:10}}>{err}</div>}
        <button className="btn primary" style={{width:'100%', justifyContent:'center', marginTop:14}} onClick={submit}>
          Login
        </button>
      </div>
    </div>
  )
}
