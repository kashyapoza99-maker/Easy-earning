import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Topbar from './components/Topbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Recharge from './pages/Recharge'
import Claim from './pages/Claim'
import Withdraw from './pages/Withdraw'
import Referral from './pages/Referral'
import Kyc from './pages/Kyc'
import Support from './pages/Support'
import AdminLogin from './pages/admin/AdminLogin'
import AdminDashboard from './pages/admin/AdminDashboard'

export default function App(){
  return (
    <BrowserRouter>
      <Topbar/>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/recharge" element={<Recharge/>} />
        <Route path="/claim" element={<Claim/>} />
        <Route path="/withdraw" element={<Withdraw/>} />
        <Route path="/referral" element={<Referral/>} />
        <Route path="/kyc" element={<Kyc/>} />
        <Route path="/support" element={<Support/>} />

        <Route path="/admin" element={<AdminLogin/>} />
        <Route path="/admin/dashboard" element={<AdminDashboard/>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Footer/>
    </BrowserRouter>
  )
}
