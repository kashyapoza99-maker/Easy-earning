import React from 'react'
export default function Footer(){
  return (
    <div className="container footer">
      <hr/>
      <div style={{display:'flex',flexWrap:'wrap',gap:14,justifyContent:'space-between',alignItems:'center'}}>
        <div>© {new Date().getFullYear()} Easy Earning • Demo Template</div>
        <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
          <a href="#">Terms</a>
          <a href="#">Privacy</a>
          <a href="#">Support</a>
        </div>
      </div>
    </div>
  )
}
