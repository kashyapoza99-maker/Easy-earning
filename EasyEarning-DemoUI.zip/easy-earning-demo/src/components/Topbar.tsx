import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { ShieldCheck, LogIn } from 'lucide-react'
import logo from '../assets/logo.svg'

const links = [
  {to:'/', label:'Home'},
  {to:'/dashboard', label:'Dashboard'},
  {to:'/recharge', label:'Recharge'},
  {to:'/withdraw', label:'Withdraw'},
  {to:'/referral', label:'Referral'},
  {to:'/support', label:'Support'},
]

export default function Topbar(){
  const loc = useLocation()
  return (
    <div className="topbar">
      <div className="nav">
        <div className="nav-left">
          <Link to="/" className="brand">
            <img src={logo} alt="Easy Earning"/>
            <div>
              <div className="brand-title">Easy Earning</div>
              <div className="small" style={{marginTop:2}}>Demo UI • Black & Gold</div>
            </div>
          </Link>
          <span className="badge"><ShieldCheck size={14}/> KYC Protected</span>
        </div>

        <div className="nav-links">
          {links.map(l=>(
            <Link key={l.to} to={l.to} style={{
              opacity: loc.pathname===l.to?1:.8,
              padding:'8px 10px', borderRadius:12,
              border: loc.pathname===l.to?'1px solid var(--border)':'1px solid transparent'
            }}>{l.label}</Link>
          ))}
          <Link to="/admin" className="btn ghost" style={{padding:'8px 10px'}}><LogIn size={16}/> Admin</Link>
        </div>

        <div style={{display:'flex', gap:10}}>
          <Link className="btn primary" to="/login"><LogIn size={16}/> Login</Link>
        </div>
      </div>
    </div>
  )
}
